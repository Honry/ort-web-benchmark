onnx.parser
===========


parse_function
++++++++++++++

.. autofunction:: onnx.parser.parse_function

parse_graph
+++++++++++

.. autofunction:: onnx.parser.parse_graph

parse_model
+++++++++++

.. autofunction:: onnx.parser.parse_model

