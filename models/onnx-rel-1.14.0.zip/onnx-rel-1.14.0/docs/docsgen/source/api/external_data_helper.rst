
onnx.external_data_helper
=========================


convert_model_from_external_data
++++++++++++++++++++++++++++++++

.. autofunction:: onnx.external_data_helper.convert_model_from_external_data

convert_model_to_external_data
++++++++++++++++++++++++++++++

.. autofunction:: onnx.external_data_helper.convert_model_to_external_data

ExternalDataInfo
++++++++++++++++

.. autoclass:: onnx.external_data_helper.ExternalDataInfo

load_external_data_for_model
++++++++++++++++++++++++++++

.. autofunction:: onnx.external_data_helper.load_external_data_for_model

load_external_data_for_tensor
+++++++++++++++++++++++++++++

.. autofunction:: onnx.external_data_helper.load_external_data_for_tensor

remove_external_data_field
++++++++++++++++++++++++++

.. autofunction:: onnx.external_data_helper.remove_external_data_field

save_external_data
++++++++++++++++++

.. autofunction:: onnx.external_data_helper.save_external_data

set_external_data
+++++++++++++++++

.. autofunction:: onnx.external_data_helper.set_external_data

write_external_data_tensors
+++++++++++++++++++++++++++

.. autofunction:: onnx.external_data_helper.write_external_data_tensors

