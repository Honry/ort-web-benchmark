onnx.backend
============

Backend
+++++++

.. autoclass:: onnx.backend.base.Backend
    :members:

BackendRep
++++++++++

.. autoclass:: onnx.backend.base.BackendRep
    :members:

Device
++++++

.. autoclass:: onnx.backend.base.Device
    :members:

DeviceType
++++++++++

.. autoclass:: onnx.backend.base.DeviceType
    :members:

load_model_tests
++++++++++++++++

.. autofunction:: onnx.backend.test.loader.load_model_tests
