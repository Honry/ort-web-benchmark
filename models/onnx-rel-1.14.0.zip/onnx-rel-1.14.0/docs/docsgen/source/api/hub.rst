
onnx.hub
========


ModelInfo
+++++++++

.. autoclass:: onnx.hub.ModelInfo
    :members:

list_models
+++++++++++

.. autofunction:: onnx.hub.list_models

get_model_info
++++++++++++++

.. autofunction:: onnx.hub.get_model_info

load
++++

.. autofunction:: onnx.hub.load
