.. Copyright (c) ONNX Project Contributors
..
.. SPDX-License-Identifier: Apache-2.0

.. _onnx-technical:

Technical Details
=================

This section enters into implementation details, technical descriptions,
deeper than the code documentation.

.. toctree::
    :maxdepth: 2

    float8
