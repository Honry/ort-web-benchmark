<!--
Copyright (c) ONNX Project Contributors

SPDX-License-Identifier: Apache-2.0
-->

# Relicensing MIT to Apache-2.0

The following copyright holders agree that all of their contributions originally submitted to this project under the MIT license are hereby relicensed to Apache-2.0, and are submitted pursuant to the Developer Certificate of Origin, version 1.1:

Intel Corporation
Microsoft Corporation
NVIDIA Corporation
IBM Corporation
Facebook Inc.
