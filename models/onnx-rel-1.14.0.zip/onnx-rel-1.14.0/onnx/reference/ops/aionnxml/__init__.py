# SPDX-License-Identifier: Apache-2.0

from onnx.reference.ops.aionnxml._op_list import load_op
